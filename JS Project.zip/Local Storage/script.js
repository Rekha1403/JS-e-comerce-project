

localStorage.setItem("data",JSON.stringify({name:"Virat Kohli"}))


